import React, { useState, useEffect } from 'react'
import {NavLink,useHistory} from 'react-router-dom'
import { toast } from 'react-toastify';

import Loader from './include/Loader';
import Menu from './include/Menu';
import Footer from './include/Footer';
import axios from 'axios';

function Profile() {
  

  useEffect(() => {
      document.getElementById('page-loader').style.display = 'none';

      var element = document.getElementById("page-container");
      element.classList.add("show");
      
  }, []);
    
  const [{alt, src}, setImg] = useState({
      src: '',
      alt:''
  });

  const handleImg = (e) => {
      if(e.target.files[0]) {
          setImg({
              src: URL.createObjectURL(e.target.files[0]),
              alt: e.target.files[0].name
          });    
      }   
  }


  const [profileInfo, setProfileInfo] = useState({
      name:localStorage.getItem('BRUD_Admin_NAME')
  });
  const [errors, setErrors] = useState({});
  const [disable, setDisable] = useState(false);

  const InputEvent = (e) => {

      const newProfileInfo = { ...profileInfo };
      newProfileInfo[e.target.name] = e.target.value;
      setProfileInfo(newProfileInfo);

    }

    const submitHandler = (e) =>{
      e.preventDefault();
      if (validate()) {
          setDisable(true);

          const updateId = localStorage.getItem("BRUD_Admin_ID");
            
          const { name } = profileInfo;

          const myurl = "http://54.177.165.108:3000/api/admin/update-profile";
          var bodyFormData = new URLSearchParams();
          bodyFormData.append('name', name);
          bodyFormData.append('image', src);
          axios({
              method: "post",
              url: myurl,
              data: bodyFormData,
              headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          }).then((response) => {
             // console.log(response);
              if(response.data.sucecess == true){
                  
                  localStorage.setItem("BRUD_Admin_NAME",profileInfo.name);
                  setDisable(false);
                  toast.success("Profile Updated Sucessfully...!");
                  setProfileInfo({
                    name: localStorage.getItem("BRUD_Admin_NAME"),
                  });

              }else{
                  setDisable(false);
              }
              
          }).catch((error) => {
              console.log("Errors", error);
          })

        //   const updateRef = firebase.firestore().collection('admin').doc(updateId);
        //   updateRef.update({
        //       name
        //   }).then((doc) => {
        //       localStorage.setItem("BRUD_Admin_NAME",profileInfo.name);
        //       setDisable(false);
        //       toast.success("Profile Updated Sucessfully...!");
        //       setProfileInfo({
        //         name: localStorage.getItem("BRUD_Admin_NAME"),
        //       });
        // }).catch((error) => {
        //     setDisable(false);
        //     console.log("Error getting documents: ", error);
        //   });

      }
    }

    const validate = () => {
      let input = profileInfo;

      let errors = {};
      let isValid = true;
      
      if (!input["name"]) {
          isValid = false;
          errors["name_err"] = "Please enter name";
      }

      setErrors(errors);
      return isValid;
    }

    return (
        <>

            <Loader />

            <div id="page-container" className="fade page-sidebar-fixed page-header-fixed">
            
            <Menu />


            <div id="content" className="content">
            <ol className="breadcrumb float-xl-right">
               <li className="breadcrumb-item"><NavLink to="/dashboard">Dashboard</NavLink></li>
               <li className="breadcrumb-item active">Profile</li>
            </ol>
            <h1 className="page-header">Profile</h1>
            

            <div className="row">
              
            

              <div className="col-xl-6 ui-sortable">

              <div className="panel panel-inverse" data-sortable-id="form-stuff-10">

              <div className="panel-heading ui-sortable-handle">
              <h4 className="panel-title">Profile setting</h4>
              </div>


              <div className="panel-body">
                <form onSubmit={(e)=> submitHandler(e)} >
                <fieldset>

                <div className="row">
                  <div className="col-md-12 form-group">
                    <label for="exampleInputName">Name:</label>
                    <input type="text" className="form-control" id="exampleInputName" placeholder="Enter name here.." name="name" value={profileInfo.name} onChange={InputEvent} />
                    <div className="text-danger">{errors.name_err}</div>
                  </div>
                </div> 

                <div className="row">
                  <div className="col-md-12 form-group">
                    <label for="exampleInputImage">Image:</label>
                    <br/>
                    { src != '' ?
                    <img src={src} className="form-img__img-preview" style={{width:"84px",height:"84px"}} />
                    : ''
                  }
                    <input type="file" className="form-control" id="exampleInputImage" onChange={handleImg} />
                  </div>
                </div>

                <button type="submit" className="btn btn-sm btn-success m-r-5" disabled={disable}>{disable ? 'Processing...' : 'Submit'}</button>
                <button type="reset" className="btn btn-sm btn-default">Reset</button>
                
                </fieldset>
                </form>
              </div>




              </div>

              </div>



              <div className="col-xl-6 ui-sortable">

              <div className="panel panel-inverse" data-sortable-id="form-stuff-10">

              <div className="panel-heading ui-sortable-handle">
              <h4 className="panel-title">Change Password</h4>
              </div>


              <div className="panel-body">
                <form  >
                <fieldset>

                <div className="row">
                  <div className="col-md-12 form-group">
                    <label for="exampleInputOldPass">Old Password:</label>
                    <input type="text" className="form-control" id="exampleInputOldPass" placeholder="Enter old password here.." name="old_password" />
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-12 form-group">
                    <label for="exampleInputNewPass">New Password:</label>
                    <input type="text" className="form-control" id="exampleInputNewPass" placeholder="Enter new password here.." name="new_password" />
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-12 form-group">
                    <label for="exampleInputConfirmPass">Confirm Password:</label>
                    <input type="text" className="form-control" id="exampleInputConfirmPass" placeholder="Enter confirm password here.." name="confirm_password" />
                  </div>
                </div>

                <button type="submit" className="btn btn-sm btn-success m-r-5" >Submit</button>
                <button type="reset" className="btn btn-sm btn-default">Reset</button>
                
                </fieldset>
                </form>
              </div>




              </div>

              </div>



</div>
            
            
         </div>

            
            <Footer />
         
      </div>

        </>
    )
}

export default Profile
