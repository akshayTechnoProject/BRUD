import React, { useState, useEffect } from 'react'
import {NavLink,useHistory} from 'react-router-dom'
import { toast } from 'react-toastify';

import Loader from './include/Loader';
import Menu from './include/Menu';
import Footer from './include/Footer';
import axios from 'axios';


  const Restaurants = () => {

  const [restoList, setRestoList] = useState([]);

  const getResto = () => {
    const myurl = "http://54.177.165.108:3000/api/admin/restaurants-list";
          var bodyFormData = new URLSearchParams();
          bodyFormData.append('auth_code', 'Brud#Cust$&$Resto#MD');
          
          axios({
              method: "post",
              url: myurl,
              data: bodyFormData,
              headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          }).then((response) => {

            setRestoList(response['data']['data']);
              
          }).catch((error) => {
              console.log("Errors", error);
          })
  }

  useEffect(() => {
      document.getElementById('page-loader').style.display = 'none';

      var element = document.getElementById("page-container");
      element.classList.add("show");
      
      getResto()
  }, []);

console.log("ABC",restoList);

    return (
        <>

            <Loader />

            <div id="page-container" className="fade page-sidebar-fixed page-header-fixed">
            
            <Menu />


            <div id="content" className="content">
            <ol className="breadcrumb float-xl-right">
               <li className="breadcrumb-item"><NavLink to="/dashboard">Dashboard</NavLink></li>
               <li className="breadcrumb-item active">Restaurants</li>
            </ol>
            <h1 className="page-header">Restaurants</h1>
            
            <div className="card">
              <div className="card-body">
            <div className="row">
                  <div className="col-12">
                    <div className="table-responsive">
                      <table id="order-listing" className="table">
                        <thead>
                          <tr>
                            {/* <th>Sr No#</th> */}
                            <th>Image</th>
                            <th>Restaurant Name</th>
                            <th>Manager Name</th>
                            <th>Email</th>
                            <th>Phone Number</th>
                            <th>Address</th>
                            <th>Created At</th>
                          </tr>
                        </thead>
                        <tbody>
                        { 
                        restoList.map(row =>
                          <tr>
                            <td><img src={row.image} width="70px" /></td>
                            <td>{row.restaurant_name}</td>
                            <td>{row.manager_name}</td>
                            <td>{row.email}</td>
                            <td>{row.country_code+' '+row.phone_number}</td>
                            <td>{row.full_address+', '+row.state+', '+row.city}</td>
                            <td>{row.createdAt}</td>
                          </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                </div>
                </div>
            
            
         </div>

            
            <Footer />
         
      </div>

        </>
    )
}

export default Restaurants
