const ADMIN_PATH = 'brud-admin/';
const BASE_URL = 'http://localhost:3000/'+ADMIN_PATH;