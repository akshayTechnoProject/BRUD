import { Switch, Route, Redirect } from 'react-router-dom';
import Login from './components/admin/Login';
import Dashboard from './components/admin/Dashboard';
import Profile from  './components/admin/Profile';
import Restaurants from  './components/admin/Restaurants';

function App() {
  return (
    <Switch>
        <Route path="/brud-admin" exact component={Login} />
        <Route path="/admin-profile" exact component={Profile} />
        <Route path="/dashboard" exact component={Dashboard} />
        <Route path="/restaurants" exact component={Restaurants} />
        <Redirect to="/brud-admin" />
    </Switch>
  );
}

export default App;